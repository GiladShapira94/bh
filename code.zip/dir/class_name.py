class Test:
    self.name = 'test'
    def func(self,event):
        print(self.name)
        print(event)
        return self.name